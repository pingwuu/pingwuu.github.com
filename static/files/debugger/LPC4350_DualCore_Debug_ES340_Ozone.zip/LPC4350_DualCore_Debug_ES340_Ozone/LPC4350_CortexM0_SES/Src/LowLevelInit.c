/*********************************************************************
*              SEGGER MICROCONTROLLER GmbH & Co. KG                  *
*        Solutions for real time microcontroller applications        *
**********************************************************************
*                                                                    *
*        (c) 2011 SEGGER Microcontroller GmbH & Co. KG               *
*                                                                    *
* Internet: www.segger.com Support: support@segger.com               *
*                                                                    *
**********************************************************************
----------------------------------------------------------------------
File    : LowLevelInit.c
Purpose : Low level init for the LPC4350 Cortex-M0.
---------------------------END-OF-HEADER------------------------------
*/
int __low_level_init(void);
int __low_level_init(void) {
  //
  // All init is done by the Cortex-M4
  // so no need to do something here
  //
  return 1;                       // Always initialize segments !
}
