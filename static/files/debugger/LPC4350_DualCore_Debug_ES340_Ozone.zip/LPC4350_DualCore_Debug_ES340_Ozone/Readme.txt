This package includes the following projects:

  - LPC4350_CortexM0_SES (Sample project to debug the Cortex-M0 core on the LPC4350 with Embedded Studio)
  - LPC4350_CortexM4_SES (Sample project to debug the Cortex-M4 core on the LPC4350 with Embedded Studio)
  - Ozone_Multicore_LPC4350_CM0.jdebug (Sample project to debug the Cortex-M0 core on the LPC4350 with Ozone)
  - Ozone_Multicore_LPC4350_CM4.jdebug (Sample project to debug the Cortex-M4 core on the LPC4350 with Ozone)
  
*************************************************************************************************************

Simple sample projects to demonstrate dual core debugging on a LPC4350.
These projects are hardware independent but have been tested on the Arrow LPC-4350-DB1 Rev.B evaluation board

Usage Embedded Studio:
  - Start debug session with LPC4350_CortexM4_SES project
  - Open second instance of Embedded Studio and open LPC4350_CortexM0_SES
  - Start second debug session and let the Cortex-M0 run
  
Usage Ozone:
  - Start debug session with Ozone_Multicore_LPC4350_CM4.jdebug project
  - Open second instance of Ozone and open Ozone_Multicore_LPC4350_CM0.jdebug
  - Start second debug session and let the Cortex-M0 run

The Cortex-M4 simply sends a defined command to the Cortex-M0 using shared memory and waits for the response
before it resumes execution. The Cortex-M0 waits for command reception from the Cortex-M4 and simply sends
back a "received-response" using shared memory.

*************************************************************************************************************

Requirements to use these projects:
  - J-Link
  - J-Link software version V6.32g or later
  - SEGGER Embedded Studio V3.40
  - Ozone 2.56s
