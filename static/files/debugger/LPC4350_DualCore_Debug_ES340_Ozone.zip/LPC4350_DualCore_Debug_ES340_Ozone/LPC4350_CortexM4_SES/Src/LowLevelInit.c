/*********************************************************************
*              SEGGER MICROCONTROLLER GmbH & Co. KG                  *
*        Solutions for real time microcontroller applications        *
**********************************************************************
*                                                                    *
*        (c) 2011 SEGGER Microcontroller GmbH & Co. KG               *
*                                                                    *
* Internet: www.segger.com Support: support@segger.com               *
*                                                                    *
**********************************************************************
----------------------------------------------------------------------
File    : LowLevelInit.c
Purpose : Low level init for the LPC4350 Cortex-M4.
          Makes sure that the shared memory used for communication with the M0 has a defined state
---------------------------END-OF-HEADER------------------------------
*/
#include "Main.h"

int __low_level_init(void);
int __low_level_init(void) {
  //
  // Initialize communication memory
  //
  CMD_M4      = 0;
  RESPONSE_M0 = 0;
  return 1;                       // Always initialize segments !
}
